from django.apps import AppConfig


class PartnerappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "partnerapp"
